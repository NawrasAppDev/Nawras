
# Nawras (نورس) App

A bilingual school management platform built with Next.js, Supabase, and LiveKit.  
Features include login/signup, teacher/student dashboards, AI teacher chatbot, online classes, and more.

## Setup

1. Install dependencies:
```
npm install
```

2. Create `.env.local` and paste:
```
NEXT_PUBLIC_SUPABASE_URL=your_supabase_url
NEXT_PUBLIC_SUPABASE_ANON_KEY=your_anon_key
OPENAI_API_KEY=your_openai_key
LIVEKIT_URL=your_livekit_server_url
LIVEKIT_TOKEN=your_token
```

3. Run:
```
npm run dev
```

## Deploy

Push to GitHub and deploy to Vercel or Netlify.
